import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JOptionPane;
import javax.swing.Timer;
public class Lienzo extends Canvas implements MouseListener, MouseMotionListener {
    int estado=0;//estados pantallas
    int ham=50;//ham
    int sal=70;
    int abu=50;//aburrimiento
    int sed=50;//sed
    String nom;//nombre
    Timer timer;
    Imagen imagen;
  
    Imagen din = new Imagen("Ocioso(9).png",50,25,this); //Dinosaurio
    Imagen dins = new Imagen("selm.png",30,120,this); //DinosaurioS
    Imagen dins2 = new Imagen("selm2.png",30,120,this); //DinosaurioS
    Imagen fon = new Imagen("fondo.png",0,0,this); //Fondo principal
    Imagen fon2 = new Imagen("fondoselect.png",-15,-10,this); //Fondo Select
    Imagen bot = new Imagen("Boton.png",450,200,this); //Boton
    Imagen din2 = new Imagen("D2.png",250,140,this);//Dinosaurio2
    Imagen din3 = new Imagen("D3.png",490,120,this);//Dinosaurio3
    Imagen jab = new Imagen("jabon.png",10,10,this);//jabon
    Imagen car = new Imagen("carne.png",130,8,this);//carne
    Imagen ag = new Imagen("agua.png",250,13,this);//agua
    Imagen je = new Imagen("jeringa.png",350,13,this);//jeringa
    Imagen fonj = new Imagen("fondoj.png",0,0,this);//fondojuego
    Imagen pel = new Imagen("pelota.png",450,13,this);//pelota
    Imagen punteroIcono=null; //Se genera un objeto puntero,que puede referencia cualquier icono 
    int iconoSeleccionada=-1;
    int itX=10;
    int itY=10;int width = getWidth(); 
    int height = getHeight();
  
    
    public void pintarPantalla(Graphics2D g2){
        g2.drawImage(fon.imagen, fon.x,fon.y,fon.ancho,fon.alto, this);//fondo
        g2.setFont(new Font("Calibri", Font.BOLD, 35));
        g2.setColor(Color.white);
        g2.drawString("Mi Mascota",300,40);
        g2.drawImage(din.imagen, din.x,din.y,din.ancho,din.alto, this);//dinosaurio
        g2.drawImage(bot.imagen, bot.x,bot.y,bot.ancho,bot.alto, this);//boton
        
    }//pintarPantalla
    
    public void pintarMascotas(Graphics2D g2){
        g2.drawImage(fon2.imagen, fon2.x,fon2.y,fon2.ancho,fon2.alto, this);//fondoselect
        g2.setColor(Color.green);
        g2.setStroke(new BasicStroke(8.f));
        g2.drawOval(40, 130, 170, 210);//Margen dinosaurio1
        g2.setColor(Color.yellow);
        g2.drawOval(280, 130, 170, 210);//Margen dinosaurio2
        g2.setColor(Color.orange);
        g2.drawOval(495, 130, 170, 210);//Margen dinosaurio3
        g2.drawImage(dins.imagen, dins.x,dins.y,dins.ancho,dins.alto, this);
        g2.drawImage(din2.imagen, din2.x,din2.y,din2.ancho,din2.alto, this);//dinosaurio
        g2.drawImage(din3.imagen, din3.x,din3.y,din3.ancho,din3.alto, this);//dinosaurio
        //TEXTO
        
       Color color=new Color((int)(Math.random()*250),(int)(Math.random()*255),(int)(Math.random()*255));
        g2.setColor(color);
        g2.setFont(new Font("Calibri", Font.BOLD, 35)); 
        g2.drawString("Selecciona una Mascota",190,100);
      
    }//pintarPantalla
    
    public void pintarAJuego(Graphics2D g2){
        g2.drawImage(fonj.imagen, fonj.x,fonj.y,fonj.ancho,fonj.alto, this);//fondoselect
        g2.setColor(Color.green);
        g2.drawImage(dins2.imagen, dins2.x,dins2.y,dins2.ancho,dins2.alto, this);//dinosaurio
        g2.drawImage(jab.imagen, jab.x,jab.y,jab.ancho,jab.alto, this);//jabon
        g2.drawImage(car.imagen, car.x,car.y,car.ancho,car.alto, this);//carne
        g2.drawImage(ag.imagen, ag.x,ag.y,ag.ancho,ag.alto, this);//agua
        g2.drawImage(je.imagen, je.x,je.y,je.ancho,je.alto, this);//jeringa
         g2.drawImage(pel.imagen, pel.x,pel.y,pel.ancho,pel.alto, this);//pelota
        //TEXTO       
        g2.setColor(Color.orange);
        g2.setFont(new Font("ShowCard Gothic", Font.BOLD, 20)); 
        g2.drawString(nom,105,350);
        
        g2.setColor(Color.white);
        g2.setFont(new Font("ShowCard Gothic", Font.BOLD, 15)); 
        g2.drawString("\nSALUD: %"+sal,530,180);
        g2.drawString("\nHAMBRE: %"+ham,530,200);
        g2.drawString("\nSED: %"+sed,530,220);
        g2.drawString("\nABURRIMIENTO: %"+abu,530,240);
        
      
    }//pintarAJuego
    
    public Lienzo(){
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
    }
    @Override
    public void paint(Graphics g) {
        super.paint(g); //To change body of generated methods, choose Tools | Templates.
        Graphics2D g2 = (Graphics2D)g;
        g2.setBackground(Color.black);
        if (estado==0) {
            pintarPantalla(g2);
        }else if(estado==1){
            pintarMascotas(g2);
        }
        else if(estado==2){
            pintarAJuego(g2);
        }
        
    }//paint
    
     public void alimentar(){
          ham -= 15;        
    }//alimentar
     public void jugar(){
          abu-= 20; 
          ham+=15;
          sed+=30;
    }//jugar
      public void sed(){
          sed -= 25;        
    }//sed
      public void salud(){
          if(abu<50)sal-= 10;
          if(sed<50)sal-=15;
          if(ham<50)sal-=15;
    }//salud
      public void vacuna(){
          sal+=30;
    }//vacuna
    
    @Override
    public void mouseClicked(MouseEvent e) {
        if(bot.estaEnArea(e.getX(),e.getY())==true){
           JOptionPane.showMessageDialog(this, "¡Bienvenido!\n ");
           estado=1;
           repaint();        
        }
        
        if(dins2.estaEnArea(e.getX(),e.getY())==true){
           nom=JOptionPane.showInputDialog(this, "¡Genial!\n Ahora ponle un nombre...");
           estado=2;
           repaint();        
        }//din1
        if(car.estaEnArea(e.getX(),e.getY())==true){
           JOptionPane.showMessageDialog(this, "¡Ñam Ñam!...");
           alimentar();
           repaint();        
        }//carne
        if(pel.estaEnArea(e.getX(),e.getY())==true){
           JOptionPane.showMessageDialog(this, "¡Que divertido!...");
           jugar();
           repaint();        
        }//pelota
        if(ag.estaEnArea(e.getX(),e.getY())==true){
           JOptionPane.showMessageDialog(this, "¡Refrescante!...");
           sed();
           repaint();        
        }//agua
        if(je.estaEnArea(e.getX(),e.getY())==true){
           JOptionPane.showMessageDialog(this, "¡Auch!...");
           vacuna();
           repaint();        
        }//jeringa
        
         
    }
    @Override
    public void mousePressed(MouseEvent e) {
        
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        punteroIcono=null;
    }
    @Override
    public void mouseEntered(MouseEvent e) {
        
    }
    @Override
    public void mouseExited(MouseEvent e) {
       /* if(c1.estaEnArea(e.getX(),e.getY())==false){
             c1.setY(25); repaint();
        }
        if(c2.estaEnArea(e.getX(),e.getY())==false){
             c2.setY(25); repaint();
        }
        if(c3.estaEnArea(e.getX(),e.getY())==false){
             c3.setY(25); repaint();
        }
        if(c4.estaEnArea(e.getX(),e.getY())==false){
            c4.setY(25); repaint();
        }*/
    }
    @Override
    public void mouseDragged(MouseEvent e) {
    
    }
    @Override
    public void mouseMoved(MouseEvent e) {
        /*if(c1.estaEnArea(e.getX(),e.getY())==true){
            c1.setY(20); repaint();
        }
        if(c2.estaEnArea(e.getX(),e.getY())==true){
            c2.setY(20); repaint();
        }
        if(c3.estaEnArea(e.getX(),e.getY())==true){
            c3.setY(20); repaint();
        }
        if(c4.estaEnArea(e.getX(),e.getY())==true){
            c4.setY(20); repaint();
        }
    }*/
    }}
