
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc
 */
public class Frases extends Canvas{
    Frase f = new Frase();
    
    Timer timer,timer2;
    int i;
    String[] frases = {"Sólo hay dos tipos de lenguajes: aquellos de los que la gente se queja y aquellos que nadie usa.","Cualquier tonto puede escribir código que un ordenador entiende. Los buenos programadores escriben código que los humanos pueden entender."
     ,"Medir el progreso de la programación por líneas de código es como medir el progreso en la construcción de aviones por el peso.","POO(Programacion Orientada a Objetos)","Estructura de Datos","La creatividad es la inteligencia divirtiéndose."
     ,"NetBeans es un IDE","No es la especie más fuerte la que sobrevive, ni la más inteligente, sino la más receptiva al cambio.","Cambiar de respuesta es evolución. Cambiar de pregunta es revolución.","Pregúntate si lo que estás haciendo hoy te acerca al lugar en el que quieres estar mañana.",
      "La función del liderazgo es producir más líderes, no más seguidores.","Canvas para graficos","Si quieres llegar rápido, camina solo. Si quieres llegar lejos, camina en grupo.","Thread es para hilo","Si no actúas como piensas, vas a terminar pensando como actúas","No hay ninguna cosa seria que no pueda decirse con una sonrisa."
     ,"Si piensas que puedes, tú puedes. Y si piensas que no puedes, tienes razón.","Mundo perdido","Acepta la responsabilidad de hacer de tus sueños una realidad.","Si solo lees los libros que todos leen, solo pensarás lo que los otros piensan.","Hola Mundo",
      "Sé amable con todos y severo contigo mismo.","Si te caíste ayer, levántate hoy.","ISC","Un adulto creativo es un niño que ha sobrevivido","No se trata bits, bytes y protocolos, sino de beneficios, pérdidas y márgenes","Background","Base de Datos","ForeGround","Alexis Moreno Jauregui",
      "Somos Microsoft. La resistencia es inútil. Serás absorbido","Inteligencia Artificial","Controlar la complejidad es la esencia de la programación","La función de un buen software es hacer que lo complejo aparente ser simple","Lenguaje Maquina","Iterar es humano, 'recursivar' es divino",
      "Java es, en muchos sentidos, C++","El software es como el sexo: mejor si es libre y gratis","El buen código es su mejor documentación","¡No me importa si funciona en tu máquina! ¡No estamos vendiendo tu máquina!"};
    
    public Frases(){
     
        
        
        timer = new Timer(200, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
                f.rebotar();
                repaint();
                
            
                timer2.start();
             }   
        });
        
        timer2 = new Timer(20000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                i = (int)(Math.random()*39);
                f.rebotar();
                repaint();
            }
        });
        
    }
    
    @Override
    public void paint(Graphics g) {
        super.paint(g); 
        Graphics2D g2 = (Graphics2D)g;
        
        f.pintar(g2,frases[i]);
    }
    
        
        
        
    
    
    
}
