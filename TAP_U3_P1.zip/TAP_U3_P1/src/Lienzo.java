/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alexis Moreno
 */
import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.Timer;
/*
    
*/
/**
 *
 * @author Admin
 */
public class Lienzo extends Canvas {
   String[] frases ={"Uno","Dos","Tres","Cuatro","Cinco","Seis","Siete","Ocho","Nueve",
   "Diez","Once","Doce","Trece","Catorce","Quince","Dieciséis","Diecisiete","Dieciocho","Diecinueve","Veinte","Veintiuno",
   "VeintiDos","23","24","25","26","27","28","29","30","31","32",
   "33","34","35","36","37","38","39","40"};
    
    Dimension arcs = new Dimension(15,15); 
    int width = getWidth(); 
    int height = getHeight();
    
   
    public void paint(Graphics g) {
        super.paint(g); //To change body of generated methods, choose Tools | Templates.
        Graphics2D g2 =(Graphics2D)g;
        this.setBackground(Color.DARK_GRAY);

        //Agregar un rectangulo de puntas redondas
        g2.setColor(Color.blue);
        g2.fillRoundRect(180, 170, 400, 30, arcs.width, arcs.height);
        g2.setColor(Color.BLACK);
        g2.drawRoundRect(180, 170, 400, 30, arcs.width, arcs.height);
  
        Timer t = new Timer(2000, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            for (int i = 0; i <frases.length; i++) {
                g2.drawString("Hola", i, i);
                
            }
 
            
            
        }
    });
    }

  
}