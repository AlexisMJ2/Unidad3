
import java.awt.Color;
import static java.lang.Thread.sleep;
import javax.swing.*;



public class Sem2 extends Thread {
    JLabel Carro2;   
    JLabel Carro4; 
    public boolean ejecutar;
    public JButton Rojo2;
    public JButton Amarillo2;
    public JButton Verde2;
    public int contador=0,temp=0,temp2=0,temp3=0,temp4=0;
 
    
    public Sem2(JButton R,JButton A,JButton V, JLabel C2, JLabel C4){
       this.Carro2=C2; 
       this.Carro4=C4;
       this.Rojo2=R;
       this.Amarillo2=A;
       this.Verde2=V;
    
    }

    
    @Override
    public void run() {
         
        while(ejecutar){
            
            contador++;
             
            if(contador>=1 && contador<=6){
                temp++;
            }
            if(contador<6){
                Rojo2.setBackground(Color.gray);
                Amarillo2.setBackground(Color.gray);
                Verde2.setBackground(Color.green);
                           
                   for (int i = 0; i < 10; i++) 
                         
                Carro2.setLocation(Carro2.getX(), Carro2.getY()-8);
                Carro4.setLocation(Carro4.getX(), Carro4.getY()-60);
                
            }
            
            if(contador>=6 && contador<=10){
                temp2++;
            }
            if(contador==6){
              Rojo2.setBackground(Color.gray);
              Amarillo2.setBackground(Color.yellow);
              Verde2.setBackground(Color.gray);  
            }
            
            
            if(contador>=10 && contador<=15){
                temp3++;
            }
            
            if(contador==10){
              Rojo2.setBackground(Color.red);
              Amarillo2.setBackground(Color.gray);
              Verde2.setBackground(Color.gray);   
                }
            //
            if(contador>=15 && contador<=19){
                temp4++;
            }
            if(contador==15){
              Rojo2.setBackground(Color.gray);
              Amarillo2.setBackground(Color.yellow);
              Verde2.setBackground(Color.gray);  
              Carro2.setLocation(Carro2.getX(), Carro2.getY()-50);
              Carro4.setLocation(Carro4.getX(), Carro4.getY()-50);
            }
            
            
            if(contador==18){
                contador=0;
                temp=0;
                temp2=0;
                temp3=0;
                temp4=0;
                Carro2.setLocation(335, 330);
                Carro4.setLocation(355, 330);
            }
            
            try {
                 
                sleep(1000);
                
            } catch (Exception e) {
            }
            
        }  
    }
    
    public void start() {
       ejecutar = true;
       new Thread(this).start();
    }
    
}
