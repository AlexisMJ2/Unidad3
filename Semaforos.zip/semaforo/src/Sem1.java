
import java.awt.Color;
import static java.lang.Thread.sleep;
import javax.swing.*;



public class Sem1 extends Thread {
    JLabel Carro1;
    JLabel Carro3;
    public boolean ejecutar;
    public JButton Rojo;
    public JButton Amarillo;
    public JButton Verde;
    public JTextField Tiempo;
    public int contador=0,temp=0,temp2=0,temp3=0,temp4=0;
 
    
    public Sem1(JButton R,JButton A,JButton V,JTextField T, JLabel C1,JLabel C3){
       this.Carro1= C1; 
       this.Carro3= C3; 
       this.Rojo=R;
       this.Amarillo=A;
       this.Verde=V;
       this.Tiempo=T;
    
    }

    @Override
    public void run() {
         
        while(ejecutar){
            
            contador++;
             
            if(contador>=1 && contador<=6){
                temp++;
                Tiempo.setText(""+temp);
            }
            if(contador==1){
                Rojo.setBackground(Color.red);
                Amarillo.setBackground(Color.gray);
                Verde.setBackground(Color.gray);   
                }
            
          
            if(contador>=6 && contador<=10){
                temp2++;
                Tiempo.setText(""+temp2);
            }
            if(contador==6){
              Rojo.setBackground(Color.gray);
              Amarillo.setBackground(Color.yellow);
              Verde.setBackground(Color.gray);  
            }
            
            
            if(contador>=10 && contador<=15){
                temp3++;
                Tiempo.setText(""+temp3);
            }
            if(contador>=10 && contador<15){
              Rojo.setBackground(Color.gray);
              Amarillo.setBackground(Color.gray);
              Verde.setBackground(Color.green); 
              
              for (int i = 0; i < 15; i++)             
                
                Carro1.setLocation(Carro1.getX()-10, Carro1.getY());
                Carro3.setLocation(Carro3.getX()-85, Carro3.getY());
            }
            
            
            if(contador>=15 && contador<=19){
                temp4++;
                Tiempo.setText(""+temp4);
            }
            if(contador==15){
              Rojo.setBackground(Color.gray);
              Amarillo.setBackground(Color.yellow);
              Verde.setBackground(Color.gray);   
              Carro1.setLocation(Carro1.getX()-115, Carro1.getY());
              Carro3.setLocation(Carro3.getX()-100, Carro1.getY());
            }
            
            
            if(contador==18){
                contador=0;
                temp=0;
                temp2=0;
                temp3=0;
                temp4=0;
                Carro1.setLocation(450,213);
                Carro3.setLocation(460,180);
            }
            
            try {
                sleep(1000);
                
                
            } catch (Exception e) {
            }
            
        }  
    }
    
     public void start() {
       ejecutar = true;
       new Thread(this).start();
    }
    
   
}
